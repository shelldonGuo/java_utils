#define REDIS_GIT_SHA1 "a41bac7c"
#define REDIS_GIT_DIRTY "0"
#define REDIS_BUILD_ID "guoxuedong-OptiPlex-9020-1443082737"
