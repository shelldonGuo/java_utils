./cauchy_02 3 3 3 100 2
